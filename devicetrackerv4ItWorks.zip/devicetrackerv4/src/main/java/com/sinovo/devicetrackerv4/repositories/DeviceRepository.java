package com.sinovo.devicetrackerv4.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sinovo.devicetrackerv4.models.Device;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Integer> {

	@Query(value="select * from Device d where " 
			+ " d.id 						like %:keyword% or"
			+ " d.device_model_description 	like %:keyword% or "
			+ " d.manufacturer    			like %:keyword% or "
			+ " d.current_borrower    		like %:keyword% or "
			+ " d.siunit    				like %:keyword% or "
			+ " d.serial_no    				like %:keyword% or "
			+ " d.si_diary_driver    			like %:keyword% or "
			+ " d.driverguid    			like %:keyword% or "
			+ " d.win_driver32B    			like %:keyword% or "
			+ " d.win_driver64B    			like %:keyword% or "
			+ " d.cable    					like %:keyword% or "
			+ " d.added_date    				like %:keyword% or "
			+ " d.testplan_available    		like %:keyword% or "
			+ " d.cjktest_chin    			like %:keyword% or "
			+ " d.comment    				like %:keyword% or "
			+ " d.label    					like %:keyword% or "
			+ "d.device_id_description 		like %:keyword%", nativeQuery = true)//needs to match the column names exactly
	List<Device> findByKeyword(@Param("keyword") String keyword);
	
	
}
