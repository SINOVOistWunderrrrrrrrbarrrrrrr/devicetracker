package com.sinovo.devicetrackerv4;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ApplicationController {
	
	//method to return the homepage:
	@GetMapping("/index")
	public String goHome()
	{
		return "redirect:/devices";
	}
	
	//method to return the login page:
	@GetMapping("/login")
	public String login()
	{
		return "login";
	}
	
	//method to return the logout page:
	@GetMapping("/logout")
	public String logout()
	{
		return "login";
	}
		
	//method to return the logout page:
	@GetMapping("/register")
	public String register()
	{
		return "register";
	}
	
	@GetMapping("/forgotPassword")
	public String forgotPassword()
	{
		return "forgotPassword";
	}
	
	@GetMapping("/newPasswordWasSent")
	public String newPasswordWasSent()
	{
		return "newPasswordWasSent";
	}

}
