
$('document').ready(function() {
	
	$('.table #editButton').on('click',function(event){		
		event.preventDefault();		
		var href= $(this).attr('href');			
		$.get(href, function(device, status){
			$('#txtIdEdit').val(device.id);
			$('#deviceIdDescriptionEdit').val(device.deviceIdDescription);
			$('#deviceModelDescriptionEdit').val(device.deviceModelDescription);	
			$('#currentBorrowerEdit').val(device.currentBorrower);
		});			
		$('#editModal').modal();		
	});
	
	$('.table #detailsButton').on('click',function(event) {
		event.preventDefault();		
		var href= $(this).attr('href');	
		$.get(href, function(device, status){
			$('#idDetails').val(device.id);
			$('#deviceIdDescriptionDetails').val(device.deviceIdDescription);
			$('#deviceModelDescriptionDetails').val(device.deviceModelDescription);
			$('#currentBorrowerDetails').val(device.currentBorrower);
			//$('#lastModifiedByDetails').val(country.lastModifiedBy);
			//$('#lastModifiedDateDetails').val(country.lastModifiedDate.substr(0,19).replace("T", " "));
		});			
		$('#detailsModal').modal();		
	});	
	
	$('.table #deleteButton').on('click',function(event) {
		event.preventDefault();
		var href = $(this).attr('href');
		$('#deleteModal #confirmDeleteButton').attr('href', href);
		$('#deleteModal').modal();		
	});	
	
	
	
	$('#txtSearch').on('keyup',function(){
		var devices;  /* = [[${devices}]]*/
		var value = $(this).val();
		
		//Get Filtered employee list 
		var data = FilterFunction(value, devices);
		
		//Clear the table and rebuild using new filtered data
		rebuildTable(data)				
	});
  
	
	   function FilterFunction(value, data){	   
		   var filteredData = [];	   
		   for(var i = 0; i<data.length; i++) {
			   value = value.toLowerCase();
			   var fdevIdDescr = data[i].deviceIdDescriptionDetails.toLowerCase();
			   var fmodelDescr = data[i].deviceModelDescription.toLowerCase();
			   var fcurrBorrower = data[i].currentBorrower.toLowerCase();
			   
			   if(fdevIdDescr.includes(value) || fmodelDescr.includes(value) || fcurrBorrower.includes(value)){
				   filteredData.push(data[i]);
			   }
		   }	   
		   return filteredData;
	   }
	
	   
	   function rebuildTable(data){
			var table = document.getElementById('devicesTable')
			table.innerHTML=''
			for(var i = 0; i <data.length; i++) {
				var row = `<tr>
								<td>${data[i].id}</td>
								<td>${data[i].deviceIdDescriptionDetails}</td>
								<td>${data[i].deviceModelDescription}</td>
								<td>${data[i].currentBorrower}</td>
				          </tr>`
				          table.innerHTML += row
			}
	  }
	  
	
});