package com.sinovo.devicetrackerv7.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sinovo.devicetrackerv7.models.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	/*
	 * Here, method name must be 'findBy' + 'fieldNameOfEntity'
	 * in order to be found by springsecurity.
	 */
	User findByUsername(String username);
	
	User findByFirstnameAndLastname(String firstname, String lastname);
	
}
