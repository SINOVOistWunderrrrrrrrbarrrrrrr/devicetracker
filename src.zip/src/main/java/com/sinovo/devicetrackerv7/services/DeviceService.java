package com.sinovo.devicetrackerv7.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinovo.devicetrackerv7.models.Device;
import com.sinovo.devicetrackerv7.repositories.DeviceRepository;

@Service
public class DeviceService {
	
	@Autowired
	private DeviceRepository deviceRepository;
	
//	public List<Device> getDevices() {
//		return  deviceRepository.findAll();
//	}
	
	//Get All Devices
	public List<Device> findAll(){
		
		return deviceRepository.findAll();
	}	
	
	//Get Device By Id
	public Optional<Device> findById(int id) {
		//Optional<Device> test = deviceRepository.findById(id);
		//System.out.println("DeviceService findById: " + test.get().getId());
		return deviceRepository.findById(id);
	}	
	
	//Delete Device
	public void delete(int id) {
		deviceRepository.deleteById(id);
	}
	
	//Update Device
	public void save( Device device) {
		
		if(!device.getCurrentBorrower().matches("") || device.getCurrentBorrower() != null)
		{
			device.setCanBeBorrowed("no");
		}
		
		deviceRepository.save(device);
	}
	
	public List<Device> findByKeyword(String keyword){
		
		return deviceRepository.findByKeyword(keyword);
	}

}
