package com.sinovo.devicetrackerv7.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sinovo.devicetrackerv7.models.User;
import com.sinovo.devicetrackerv7.models.UserPrincipal;
import com.sinovo.devicetrackerv7.repositories.UserRepository;

@Service
public class MyUserDetailsService implements UserDetailsService {
	
	public static String loggedInUserName;
	public static User loggedInUser;
	
	@Autowired
	private UserRepository  userRepository;

	/*
	 * UserDetailsService comes with Spring and
	 * delivers functionality like check credentials etc.
	 * @method loadUserByUsername checks if 
	 * username is in DB and if yes, loads an instance of User
	 * for the login session.
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		User user = userRepository.findByUsername(username);
		System.out.println("User is " + username);
		
		loggedInUser = user;
		loggedInUserName = username;
		
		if(user==null) {
			throw new UsernameNotFoundException("User not found!");
		}
 
		return new UserPrincipal(user);//no return user; here, bc. springsecurity needs return Userprincipal??
	}

}
