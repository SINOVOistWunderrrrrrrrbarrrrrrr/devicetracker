package com.sinovo.devicetrackerv7.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sinovo.devicetrackerv7.models.Device;
import com.sinovo.devicetrackerv7.services.DeviceService;
import com.sinovo.devicetrackerv7.services.MyUserDetailsService;


@Controller
public class DeviceController {
	
	@Autowired private DeviceService deviceService;
	
	private String searchWord;
	
	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	@GetMapping("/devices")
	public String findAll(Model model, String keyword){
		
		System.out.println("Logged in user's name is " + MyUserDetailsService.loggedInUserName);
		
		setSearchWord(keyword);

		if(keyword != null)
		{
		model.addAttribute("devices", deviceService.findByKeyword(keyword));
		}
		else {
			model.addAttribute("devices", deviceService.findAll());
			System.out.println("Keyword is null!");
		}

		return "Device";
	}	
	
	
	@GetMapping("/geraete")
	public String zeigeAlle(Model model, String keyword){
		
		System.out.println("Logged in user's name is " + MyUserDetailsService.loggedInUserName);
		
		setSearchWord(keyword);

		if(keyword != null)
		{
		model.addAttribute("devices", deviceService.findByKeyword(keyword));
		}
		else {
			model.addAttribute("devices", deviceService.findAll());
			System.out.println("Keyword is null!");
		}

		return "geraet";
	}
	
	@RequestMapping("devices/findById") 
	@ResponseBody
	public Optional<Device> findById(Integer id)
	{
		return deviceService.findById(id);
	}
	
	@RequestMapping("geraete/findeNachId") 
	@ResponseBody
	public Optional<Device> findeNachId(Integer id)
	{
		return deviceService.findById(id);
	}
	
	//Add Device
	@PostMapping(value="devices/addNew")
	public String addNew(Device device) {
		
		deviceService.save(device);
		
		return "redirect:/geraete";
	}	
	
	@PostMapping(value="geraete/fuegeHinzu")
	public String fuegeHinzu(Device device) {
		
		deviceService.save(device);

		return "redirect:/geraete";
	}
	
	
	@RequestMapping(value="devices/update", method = {RequestMethod.PUT, RequestMethod.GET})
	public String update(Device device, Model model) {

		deviceService.save(device);
		
		if(searchWord != null)
		{
			System.out.println("Inside DeviceController update - if. ");
		model.addAttribute("devices", deviceService.findByKeyword(searchWord));
		return "Device";
		}
		else {
			System.out.println("Inside DeviceController update - else. ");
			model.addAttribute("devices", deviceService.findAll());
			return "redirect:/devices";
		}

		//return "Device";
		
		//return "redirect:/devices";
	}
	
	
	@RequestMapping(value="geraete/updaten", method = {RequestMethod.PUT, RequestMethod.GET})
	public String updaten(Device device, Model model) {

		deviceService.save(device);

		if(searchWord != null)
		{
			System.out.println("Inside DeviceController update - if. ");
		model.addAttribute("devices", deviceService.findByKeyword(searchWord));
		return "geraet";
		}
		else {
			System.out.println("Inside DeviceController update - else. ");
			model.addAttribute("devices", deviceService.findAll());
			return "redirect:/geraete";
		}

		//return "Device";
		
		//return "redirect:/devices";
	}
	
	
	@RequestMapping(value="devices/delete", method = {RequestMethod.DELETE, RequestMethod.GET})	
	public String delete(Integer id) {
		
			deviceService.delete(id);
			
		return "redirect:/devices";
	}
	
	
	@RequestMapping(value="geraete/loeschen", method = {RequestMethod.DELETE, RequestMethod.GET})	
	public String loeschen(Integer id) {
		
			deviceService.delete(id);
			
		return "redirect:/geraete";
	}
	
	
}
