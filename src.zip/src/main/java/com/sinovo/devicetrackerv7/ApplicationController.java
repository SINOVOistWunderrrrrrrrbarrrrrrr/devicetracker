package com.sinovo.devicetrackerv7;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/*
 *  @Controller in Spring is a specialization of the @Component class.
 *   It allows Spring to auto-detect implementation classes through the classpath scanning. 
 *   Is typically used in combination with a @RequestMapping annotation for request handling methods.
 */
@Controller
public class ApplicationController {
	
	/*
	 * Method to return the homepage.
	 * @return
	 * Returns the index.html file in the browser
	 */
	@GetMapping("/index")
	public String goHome()
	{
		return "index";
	}
	
	//@return
	//Returns the german version of the index.html file
	@GetMapping("/indexger")
	public String nachHause()
	{
		System.out.println("Nach Hause!");
		return "indexdeutsch";
	}
	
	//Method to return the login page:
	@GetMapping("/login")
	public String login()
	{
		return "login";
	}
	
	//For after deployment on tomcat 8.5.23:
	@GetMapping("/devicetracker")
	public String goToStartPage()
	{
		return "index";
	}
	
	//Method to return the logout page:
	@GetMapping("/logout")
	public String logout()
	{
		return "login";
	}
		
	//Method to return the register new user page:
	@GetMapping("/register")
	public String register()
	{
		return "register";
	}
	
//	@GetMapping("/forgotPassword")
//	public String forgotPassword()
//	{
//		return "forgotPassword";
//	}
//	
//	@GetMapping("/newPasswordWasSent")
//	public String newPasswordWasSent()
//	{
//		return "newPasswordWasSent";
//	}

}
