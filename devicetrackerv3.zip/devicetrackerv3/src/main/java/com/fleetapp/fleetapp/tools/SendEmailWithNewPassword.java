package com.fleetapp.fleetapp.tools;

import java.nio.charset.Charset;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmailWithNewPassword {
	/*
	 * https://www.tutorialspoint.com/java/java_sending_email.htm
	 */
	public static void sendEmailWithNewPassword(String givenEmail)
	{
		 // Recipient's email ID needs to be mentioned.
	      String to = givenEmail;//"abcd@gmail.com";

	      // Sender's email ID needs to be mentioned
	      String from = "ines.drebenstedt@googlemail.com";

	      // Assuming you are sending email from localhost
	      String host = "smtp.googlemail.com"; //"localhost";

	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);

	      // Get the default Session object.
	      Session session = Session.getDefaultInstance(properties);

	      try {
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

	         //Test:
	         byte[] array = new byte[7]; // length is bounded by 7
	         new Random().nextBytes(array);
	         String generatedString = new String(array, Charset.forName("UTF-8"));

	         //System.out.println(generatedString);
	         // Set Subject: header field
	         message.setSubject("This is your new password: " + generatedString);

	         // Now set the actual message
	         message.setText("Please change password after re-login.");

	         // Send message
	         Transport.send(message);
	         System.out.println("Sent message successfully....");
	      } catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
		
	}

}
