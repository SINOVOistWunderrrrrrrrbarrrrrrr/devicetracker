package com.fleetapp.fleetapp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Device {
		
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;

	private String deviceIdDescription;//Gerät
	private String manufacturer;//Hersteller	
	private String deviceModelDescription;//
	private String currentBorrower;
	private String SIunit;//Einheit
	private String serialNo;
	private String SiDiaryDriver;
	private String driverGUID;
	private String WinDriver32B;
	private String WinDriver64B;
	private String cable;
	private String addedDate;
	private String testplanAvailable;
	private String CJKTestChin;
	private String comment;
	private String label;
	
	private String canBeBorrowed;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeviceIdDescription() {
		return deviceIdDescription;
	}

	public void setDeviceIdDescription(String deviceIdDescription) {
		this.deviceIdDescription = deviceIdDescription;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getDeviceModelDescription() {
		return deviceModelDescription;
	}

	public void setDeviceModelDescription(String deviceModelDescription) {
		this.deviceModelDescription = deviceModelDescription;
	}

	public String getCurrentBorrower() {
		return currentBorrower;
	}

	public void setCurrentBorrower(String currentBorrower) {
		this.currentBorrower = currentBorrower;
	}

	public String getSIunit() {
		return SIunit;
	}

	public void setSIunit(String sIunit) {
		SIunit = sIunit;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getSiDiaryDriver() {
		return SiDiaryDriver;
	}

	public void setSiDiaryDriver(String siDiaryDriver) {
		SiDiaryDriver = siDiaryDriver;
	}

	public String getDriverGUID() {
		return driverGUID;
	}

	public void setDriverGUID(String driverGUID) {
		this.driverGUID = driverGUID;
	}

	public String getWinDriver32B() {
		return WinDriver32B;
	}

	public void setWinDriver32B(String winDriver32B) {
		WinDriver32B = winDriver32B;
	}

	public String getWinDriver64B() {
		return WinDriver64B;
	}

	public void setWinDriver64B(String winDriver64B) {
		WinDriver64B = winDriver64B;
	}

	public String getCable() {
		return cable;
	}

	public void setCable(String cable) {
		this.cable = cable;
	}

	public String getAddedDate() {
		return addedDate;
	}

	public void setAddedDate(String addedDate) {
		this.addedDate = addedDate;
	}

	public String getTestplanAvailable() {
		return testplanAvailable;
	}

	public void setTestplanAvailable(String testplanAvailable) {
		this.testplanAvailable = testplanAvailable;
	}

	public String getCJKTestChin() {
		return CJKTestChin;
	}

	public void setCJKTestChin(String cJKTestChin) {
		CJKTestChin = cJKTestChin;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getCanBeBorrowed() {
		return canBeBorrowed;
	}

	public void setCanBeBorrowed(String canBeBorrowed) {
		this.canBeBorrowed = canBeBorrowed;
	}
	
	
	
	
}
