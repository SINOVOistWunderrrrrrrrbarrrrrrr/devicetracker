package com.fleetapp.fleetapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.fleetapp.fleetapp.models.Employee;
import com.fleetapp.fleetapp.models.User;
import com.fleetapp.fleetapp.repositories.EmployeeRepository;
import com.fleetapp.fleetapp.repositories.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	
	
	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}


	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	//Get All Users
	public List<User> findAll(){
		return userRepository.findAll();
	}	
	
	//Get User By Id
	public Optional<User> findById(int id) {
		return userRepository.findById(id);
	}	
	
	//Delete User
	public void delete(int id) {
		userRepository.deleteById(id);
	}
	
	//Update User
	public void save(User user) {
		//encode password before saving
		//by using the setter:
		user.setPassword(encoder.encode(user.getPassword()));
				
		userRepository.save(user);
	}
	
	
	//
	public User findByUserName(String username) {
		return userRepository.findByUsername(username);
	}
	
	
	//
	public User findByFirstnameAndLastname(String firstname, String lastname) {
		return userRepository.findByFirstnameAndLastname(firstname, lastname);
	}
	
	
//	//Set the Employee Id of the user where firstname and lastname match
//	public int getCorrespondingEmployeeId(String currentUser){
//		Employee correspondingEmployee = employeeRepository.findByUsername(currentUser);
//		return correspondingEmployee.getId();
//	}

	public boolean checkIfUsernameAvailable(String newUsername)
	{
		boolean usernameAvailable = true;
		
		List<User> usersInDB = userRepository.findAll();
		
		for(User user : usersInDB)
		{
			if(user.getUsername().matches(newUsername))
			{
				usernameAvailable = false;
			}
		}
		
		return usernameAvailable;
	}
	
}
