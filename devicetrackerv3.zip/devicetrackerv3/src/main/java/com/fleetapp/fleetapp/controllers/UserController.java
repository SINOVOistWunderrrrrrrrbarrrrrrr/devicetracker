package com.fleetapp.fleetapp.controllers;

import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.fleetapp.fleetapp.models.User;
import com.fleetapp.fleetapp.services.UserService;
import com.fleetapp.fleetapp.tools.SendEmailWithNewPassword;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	// Get All Users
//	@GetMapping("/users")
//	public String getUsers()
//	{
//		return "User";
//	}

	@GetMapping("/users")
	public String findAll(Model model) {
		model.addAttribute("users", userService.findAll());
		return "User";
	}

	@RequestMapping("users/findById")
	@ResponseBody
	public Optional<User> findById(Integer id) {
		return userService.findById(id);
	}

//	@RequestMapping("users/findByUserName") 
//	@ResponseBody
//	public User findByUserName(String username)
//	{
//		return userService.findByUserName(username);
//	}

	// Add User
//	@PostMapping(value="users/addNew")
//	public String addNew(User user) {
//		userService.save(user);
//		return "redirect:/users";
//	}	

	// Modified method to Add a new user User
	@PostMapping(value = "users/addNew")
	public RedirectView addNew(User user, RedirectAttributes redir) {
		RedirectView redirectView;

		if (userService.checkIfUsernameAvailable(user.getUsername())) {
			userService.save(user);
			redirectView = new RedirectView("/login", true);
			redir.addFlashAttribute("message", "You successfully registered! You can now login");
		} else {
			redirectView = new RedirectView("/register", true);
			redir.addFlashAttribute("error", "Username already taken! Go to login page or choose different username.");
		}

		return redirectView;
	}

	@RequestMapping(value = "users/update", method = { RequestMethod.PUT, RequestMethod.GET })
	public String update(User user) {
		userService.save(user);
		return "redirect:/users";
	}

	@RequestMapping(value = "users/delete", method = { RequestMethod.DELETE, RequestMethod.GET })
	public String delete(Integer id) {
		userService.delete(id);
		return "redirect:/users";
	}
	
	@RequestMapping(value = "forgotPassword")  //, method = { RequestMethod.POST, RequestMethod.GET })
	public String forgotPassword(@RequestParam("email") String email, @RequestParam("username") String username) {
		
		System.out.println("--- xxx ---");
		
		//SendEmailWithNewPassword.sendEmailWithNewPassword(email);
		
		return "redirect:/newPasswordWasSent";
	}

	
	@RequestMapping(value="/users/assignEmployee")
	public String assignUsername( Model model, Principal principal) {
		
		//model.addAttribute("employee", employeeService.findByUsername(un));
		
		return "redirect:/employees";
	}

}
