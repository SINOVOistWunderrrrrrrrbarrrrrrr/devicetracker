package com.fleetapp.fleetapp.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fleetapp.fleetapp.models.Device;
import com.fleetapp.fleetapp.services.DeviceService;
import com.fleetapp.fleetapp.services.CountryService;
import com.fleetapp.fleetapp.services.EmployeeTypeService;
import com.fleetapp.fleetapp.services.JobTitleService;
import com.fleetapp.fleetapp.services.StateService;

@Controller
public class DeviceController {
	
//	@Autowired private StateService stateService;
//	@Autowired private CountryService countryService;	
	@Autowired private DeviceService deviceService;
	
	//Get All Contacts
//	@GetMapping("/contacts")
//	public String getContacts()
//	{
//		return "Contact";
//	}
	
	@GetMapping("/devices")
	public String findAll(Model model){		
//		model.addAttribute("countries", countryService.findAll());
//		model.addAttribute("states", stateService.findAll());
		model.addAttribute("devices", deviceService.findAll());
		return "Device";
	}	
	
	@RequestMapping("devices/findById") 
	@ResponseBody
	public Optional<Device> findById(Integer id)
	{
		return deviceService.findById(id);
	}
	
	//Add Contact
	@PostMapping(value="devices/addNew")
	public String addNew(Device device) {
		deviceService.save(device);
		return "redirect:/devices";
	}	
	
	@RequestMapping(value="devices/update", method = {RequestMethod.PUT, RequestMethod.GET})
	public String update(Device device) {
		deviceService.save(device);
		return "redirect:/devices";
	}
	
	@RequestMapping(value="devices/delete", method = {RequestMethod.DELETE, RequestMethod.GET})	
	public String delete(Integer id) {
		deviceService.delete(id);
		return "redirect:/devices";
	}

}
