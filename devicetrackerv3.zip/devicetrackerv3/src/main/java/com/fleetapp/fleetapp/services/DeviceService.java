package com.fleetapp.fleetapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fleetapp.fleetapp.models.Device;
import com.fleetapp.fleetapp.repositories.DeviceRepository;

@Service
public class DeviceService {
	
	@Autowired
	private DeviceRepository deviceRepository;
	
//	public List<Device> getDevices() {
//		return  deviceRepository.findAll();
//	}
	
	//Get All Contacts
	public List<Device> findAll(){
		return deviceRepository.findAll();
	}	
	
	//Get Contact By Id
	public Optional<Device> findById(int id) {
		return deviceRepository.findById(id);
	}	
	
	//Delete Contact
	public void delete(int id) {
		deviceRepository.deleteById(id);
	}
	
	//Update Contact
	public void save( Device device) {
		deviceRepository.save(device);
	}

}
