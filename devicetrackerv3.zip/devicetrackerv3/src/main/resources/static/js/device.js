
$('document').ready(function() {
	
	$('.table #editButton').on('click',function(event){		
		event.preventDefault();		
		var href= $(this).attr('href');			
		$.get(href, function(device, status){
			$('#txtIdEdit').val(device.id);
			$('#deviceIdDescriptionEdit').val(device.deviceIdDescription);
			$('#deviceModelDescriptionEdit').val(device.deviceModelDescription);	
			$('#currentBorrowerEdit').val(device.currentBorrower);
		});			
		$('#editModal').modal();		
	});
	
	$('.table #detailsButton').on('click',function(event) {
		event.preventDefault();		
		var href= $(this).attr('href');	
		$.get(href, function(device, status){
			$('#idDetails').val(device.id);
			$('#deviceIdDescriptionDetails').val(device.deviceIdDescription);
			$('#deviceModelDescriptionDetails').val(device.deviceModelDescription);
			$('#currentBorrowerDetails').val(device.currentBorrower);
			//$('#lastModifiedByDetails').val(country.lastModifiedBy);
			//$('#lastModifiedDateDetails').val(country.lastModifiedDate.substr(0,19).replace("T", " "));
		});			
		$('#detailsModal').modal();		
	});	
	
	$('.table #deleteButton').on('click',function(event) {
		event.preventDefault();
		var href = $(this).attr('href');
		$('#deleteModal #confirmDeleteButton').attr('href', href);
		$('#deleteModal').modal();		
	});	
});