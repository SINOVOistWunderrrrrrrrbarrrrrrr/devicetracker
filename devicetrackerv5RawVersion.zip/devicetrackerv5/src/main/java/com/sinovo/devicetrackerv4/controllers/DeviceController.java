package com.sinovo.devicetrackerv4.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sinovo.devicetrackerv4.models.Device;
import com.sinovo.devicetrackerv4.services.DeviceService;

@Controller
public class DeviceController {
	
//	@Autowired private StateService stateService;
//	@Autowired private CountryService countryService;	
	@Autowired private DeviceService deviceService;
	
	private String searchWord;
	
	
	//Get All Contacts
//	@GetMapping("/contacts")
//	public String getContacts()
//	{
//		return "Contact";
//	}
	
	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	@GetMapping("/devices")
	public String findAll(Model model, String keyword){
		
		setSearchWord(keyword);

		if(keyword != null)
		{
		model.addAttribute("devices", deviceService.findByKeyword(keyword));
		}
		else {
			model.addAttribute("devices", deviceService.findAll());
			System.out.println("Keyword is null!");
		}

		return "Device";
	}	
	
	@RequestMapping("devices/findById") 
	@ResponseBody
	public Optional<Device> findById(Integer id)
	{
		System.out.println("devices/findById -> Device id result: " + id);
		return deviceService.findById(id);
	}
	
	//Add Contact
	@PostMapping(value="devices/addNew")
	public String addNew(Device device) {
		deviceService.save(device);
		
		return "redirect:/devices";
	}	
	
	@RequestMapping(value="devices/update", method = {RequestMethod.PUT, RequestMethod.GET})
	public String update(Device device, Model model) {
		deviceService.save(device);
		
		if(searchWord != null)
		{
		model.addAttribute("devices", deviceService.findByKeyword(searchWord));
		}
		else {
			model.addAttribute("devices", deviceService.findAll());
			System.out.println("Keyword is null!");
		}

		return "Device";
		
		//return "redirect:/devices";
	}
	
	@RequestMapping(value="devices/delete", method = {RequestMethod.DELETE, RequestMethod.GET})	
	public String delete(Integer id) {
		deviceService.delete(id);
		return "redirect:/devices";
	}
	
	
//	@RequestMapping(value = "devices/findByKeyword", params="keyword", method = RequestMethod.GET) 
//	public String findByKeyword(Model model, @RequestParam(name="keyword") String keyword)
//	{
//		if(keyword != null)
//			{
//			model.addAttribute("filteredDevices", deviceService.findByKeyword(keyword));
//			}
//			else {
//				model.addAttribute("filteredDevices", deviceService.findAll());
//				System.out.println("Keyword is null!");
//			}
//		
//			return "FilteredDevice";
//	}
//	
//	@GetMapping("/filteredDevices")
//	public String findAllFiltered(Model model, String keyword){	
//		System.out.println("Keyword is: " + keyword);
////		model.addAttribute("countries", countryService.findAll());
////		model.addAttribute("states", stateService.findAll());
//		model.addAttribute("filteredDevices", deviceService.findByKeyword(keyword));
//		return "FilteredDevice";
//	}	
//	
//	@RequestMapping("filteredDevices/findById") 
//	@ResponseBody
//	public Optional<Device> findFilteredById(Integer id)
//	{
//		System.out.println("filteredDevices/findById -> Device id result: " + id);
//		return deviceService.findById(id);
//	}
////	
////	
//	
//	
//	@RequestMapping(value="filteredDevices/update", method = {RequestMethod.PUT, RequestMethod.GET})
//	public String updateFilteredDevice(Device device) {
//		System.out.println("Filter result: " + device.getCurrentBorrower());
//		deviceService.save(device);
//		return "redirect:/filteredDevices";//Todo: https://stackoverflow.com/questions/25464562/load-json-data-into-a-bootstrap-modal
//	}
	
	//Gives JSON result:
//	@RequestMapping("devices/findByKeyword") 
//	@ResponseBody
//	public List<Device> findByKeyword(@RequestParam(name="keyword") String keyword)
//	{
//		this.keyword = keyword;
//		return deviceService.findByKeyword(keyword);
//	}
	
	
	
	//Gives page under http://localhost:8080/devices/findByKeyword?keyword=... without css:
//	@GetMapping("/devices/findByKeyword")
//	public String showFilteredDevices(Model model, @RequestParam(name="keyword") String keyword){		
//		if(keyword != null)
//		{
//		model.addAttribute("filteredDevices", deviceService.findByKeyword(keyword));
//		}
//		else {
//			model.addAttribute("filteredDevices", deviceService.findAll());
//			System.out.println("Keyword is null!");
//		}
//		return "FilteredDevice";
//	}	
	
}
