package com.sinovo.devicetrackerv4.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinovo.devicetrackerv4.models.Device;
import com.sinovo.devicetrackerv4.repositories.DeviceRepository;

@Service
public class DeviceService {
	
	@Autowired
	private DeviceRepository deviceRepository;
	
//	public List<Device> getDevices() {
//		return  deviceRepository.findAll();
//	}
	
	//Get All Contacts
	public List<Device> findAll(){
		return deviceRepository.findAll();
	}	
	
	//Get Contact By Id
	public Optional<Device> findById(int id) {
		Optional<Device> test = deviceRepository.findById(id);
		System.out.println("DeviceService findById: " + test.get().getId());
		return deviceRepository.findById(id);
	}	
	
	//Delete Contact
	public void delete(int id) {
		deviceRepository.deleteById(id);
	}
	
	//Update Contact
	public void save( Device device) {
		
		Device deviceToSave = new Device();
		deviceToSave = device;
		System.out.println("DeviceService save(): " 
				 + device.getId() 
				+ ", " + device.getAddedDate() 
				+ ", " + device.getAlternateLocation()
				+ ", " + device.getCable()
				+ ", " + device.getCanBeBorrowed()
				+ ", " + device.getComment()
				+ ", " + device.getCurrentBorrower()
				+ ", " + device.getDeviceIdDescription()
				+ ", " + device.getDeviceModelDescription()
				+ ", " + device.getLabel()
				+ ", " + device.getManufacturer()
				+ ", " + device.getSerialNo()
	);
		deviceRepository.save(deviceToSave);
	}
	
	public List<Device> findByKeyword(String keyword){
		
		return deviceRepository.findByKeyword(keyword);
	}

}
