
$('document').ready(function() {
	
	$('.table #editButton').on('click',function(event){		
		event.preventDefault();		
		var href= $(this).attr('href');			
		$.get(href, function(device, status){
			$('#txtIdEdit').val(device.id);
			$('#deviceIdDescriptionEdit').val(device.deviceIdDescription);
			$('#manufacturerEdit').val(device.manufacturer);			
			$('#currentBorrowerEdit').val(device.currentBorrower);	
			$('#alternateLocationEdit').val(device.alternateLocation);
			$('#siunitEdit').val(device.siunit);
			$('#serialNoEdit').val(device.serialNo);
			$('#siDiaryDriverEdit').val(device.siDiaryDriver);
			$('#driverGUIDEdit').val(device.driverguid);
			$('#winDriver32BBEdit').val(device.winDriver32B);
			$('#winDriver64BEdit').val(device.winDriver64B);
			$('#cableEdit').val(device.cable);
			$('#addedDateEdit').val(device.addedDate);
			$('#testplanAvailableEdit').val(device.testplanAvailable);
			$('#cjktestKorEdit').val(device.cjktestKor);
			$('#cjktestChinEdit').val(device.cjktestChin);
			$('#commentEdit').val(device.comment);
			$('#labelEdit').val(device.label);			
			$('#deviceModelDescriptionEdit').val(device.deviceModelDescription);
			$('#canBeBorrowedEdit').val(device.canBeBorrowed);
									
		});			
		$('#editModal').modal();		
	});
	
	$('.table #detailsButton').on('click',function(event) {
		event.preventDefault();		
		var href= $(this).attr('href');	
		$.get(href, function(device, status){
			$('#idDetails').val(device.id);
			$('#deviceIdDescriptionDetails').val(device.deviceIdDescription);
			$('#manufacturerDetails').val(device.manufacturer);
			$('#currentBorrowerDetails').val(device.currentBorrower);
			$('#alternateLocationDetails').val(device.alternateLocation);
			$('#siunitDetails').val(device.siunit);
			$('#serialNoDetails').val(device.serialNo);
			$('#siDiaryDriverDetails').val(device.siDiaryDriver);
			$('#driverGUIDDetails').val(device.driverguid);
			$('#winDriver32BBDetails').val(device.winDriver32B);
			$('#winDriver64BDetails').val(device.winDriver64B);
			$('#cableDetails').val(device.cable);
			$('#addedDateDetails').val(device.addedDate);
			$('#testplanAvailableDetails').val(device.testplanAvailable);
			$('#cjktestKorDetails').val(device.cjktestKor);
			$('#cjktestChinDetails').val(device.cjktestChin);
			$('#commentDetails').val(device.comment);
			$('#labelDetails').val(device.label);			
			$('#deviceModelDescriptionDetails').val(device.deviceModelDescription);
			$('#canBeBorrowedDetails').val(device.canBeBorrowed);
			//$('#lastModifiedByDetails').val(country.lastModifiedBy);
			//$('#lastModifiedDateDetails').val(country.lastModifiedDate.substr(0,19).replace("T", " "));
		});			
		$('#detailsModal').modal();		
	});	
	
	$('.table #deleteButton').on('click',function(event) {
		event.preventDefault();
		var href = $(this).attr('href');
		$('#deleteModal #confirmDeleteButton').attr('href', href);
		$('#deleteModal').modal();		
	});	
	
	
	
	$('#txtSearch').on('keyup',function(){
		var devices;  /* = [[${devices}]]*/
		var value = $(this).val();
		
		//Get Filtered employee list 
		var data = FilterFunction(value, devices);
		
		//Clear the table and rebuild using new filtered data
		rebuildTable(data)				
	});
  
	
	   function FilterFunction(value, data){	   
		   var filteredData = [];	   
		   for(var i = 0; i<data.length; i++) {
			   value = value.toLowerCase();
			   var fdevIdDescr = data[i].deviceIdDescriptionDetails.toLowerCase();
			   var fmodelDescr = data[i].deviceModelDescription.toLowerCase();
			   var fcurrBorrower = data[i].currentBorrower.toLowerCase();
			   
			   if(fdevIdDescr.includes(value) || fmodelDescr.includes(value) || fcurrBorrower.includes(value)){
				   filteredData.push(data[i]);
			   }
		   }	   
		   return filteredData;
	   }
	
	   
	   function rebuildTable(data){
			var table = document.getElementById('devicesTable')
			table.innerHTML=''
			for(var i = 0; i <data.length; i++) {
				var row = `<tr>
								<td>${data[i].id}</td>
								<td>${data[i].deviceIdDescriptionDetails}</td>
								<td>${data[i].deviceModelDescription}</td>
								<td>${data[i].currentBorrower}</td>
				          </tr>`
				          table.innerHTML += row
			}
	  }
	  
	
});