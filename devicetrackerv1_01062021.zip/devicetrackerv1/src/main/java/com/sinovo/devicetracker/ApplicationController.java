package com.sinovo.devicetracker;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ApplicationController {
	
	//method to return the homepage:
	@GetMapping("/index")
	public String goHome()
	{
		return "index";
	}
	
	//to be able to load device page without @...Mapping:
//	@GetMapping("/device")
//	public String device()
//	{
//		return "device";
//	}
	
	
	/*
	 * Caused by: java.lang.IllegalStateException: Ambiguous mapping. Cannot map 'deviceController' method 
com.sinovo.devicetracker.controllers.DeviceController#findAll(Model)
to {GET [/devices]}: There is already 'applicationController' bean method
com.sinovo.devicetracker.ApplicationController#devices() mapped.
	 */
//	//method to return the login page:
//	@GetMapping("/devices")
//	public String devices()
//	{
//		return "devices";
//	}
	
//	//method to return the login page:
//	@GetMapping("/login")
//	public String login()
//	{
//		return "login";
//	}
//	
//	//method to return the logout page:
//	@GetMapping("/logout")
//	public String logout()
//	{
//		return "login";
//	}
//		
//	//method to return the logout page:
//	@GetMapping("/register")
//	public String register()
//	{
//		return "register";
//	}
//	
//	@GetMapping("/forgotPassword")
//	public String forgotPassword()
//	{
//		return "forgotPassword";
//	}
//	
//	@GetMapping("/newPasswordWasSent")
//	public String newPasswordWasSent()
//	{
//		return "newPasswordWasSent";
//	}

}
