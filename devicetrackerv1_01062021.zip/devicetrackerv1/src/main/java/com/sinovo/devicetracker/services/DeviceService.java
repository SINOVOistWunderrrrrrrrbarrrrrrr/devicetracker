package com.sinovo.devicetracker.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinovo.devicetracker.models.Device;
import com.sinovo.devicetracker.repositories.DeviceRepository;

@Service
public class DeviceService {
	
	@Autowired
	private DeviceRepository deviceRepository;
	
	//Get All Vehicles
	public List<Device> findAll(){
		return deviceRepository.findAll();
	}	
	
	//Get Device By Id
	public Optional<Device> findById(int id) {
		return deviceRepository.findById(id);
	}	
	
	//Delete Device
	public void delete(int id) {
		deviceRepository.deleteById(id);
	}
	
	//Update Device
	public void save(Device device) {
		deviceRepository.save(device);
	}

	public Device findByDeviceIdDescription(String deviceIdDescription) {
		List<Device> allDevices = findAll();
		Device specificDevice = null;
		
		for(Device device : allDevices)
		{
			if(device.getDeviceIdDescription() == deviceIdDescription)
			{
				specificDevice = deviceRepository.findByDeviceIdDescription(deviceIdDescription);
			}
		}
		System.out.println("");
		return specificDevice;
		
	}
	
	public List<Device> findByKeyword(String keyword){
		
		return deviceRepository.findByKeyword(keyword);
	}
	

}
