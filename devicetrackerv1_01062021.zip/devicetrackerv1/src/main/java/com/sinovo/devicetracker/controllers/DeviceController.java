package com.sinovo.devicetracker.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sinovo.devicetracker.models.Device;
import com.sinovo.devicetracker.services.DeviceService;


@Controller
public class DeviceController {
	
	@Autowired private DeviceService deviceService;
//	@Autowired private DeviceTypeService vehicleTypeService;
//	@Autowired private DeviceMakeService vehicleMakeService;
//	@Autowired private DeviceModelService vehicleModelService;
//	@Autowired private EmployeeService employeeService ;
//	@Autowired private DeviceStatusService vehicleStatusService;


	//Get All Vehicles
//	@GetMapping("/vehicles")
//	public String getVehicles()
//	{
//		return "Device";
//	}
	
	@GetMapping("/devices")
	public String findAll(Model model){		
		model.addAttribute("devices", deviceService.findAll());
//		model.addAttribute("vehicletypes", deviceTypeService.findAll());
//		model.addAttribute("vehiclemodels", vehicleModelService.findAll());
//		model.addAttribute("vehiclemakes", vehicleMakeService.findAll());
//		model.addAttribute("employees", employeeService.findAll());
//		model.addAttribute("vehiclestatuses", vehicleStatusService.findAll());

		return "devices";
	}	
	
	@RequestMapping("devices/findById") 
	@ResponseBody
	public Optional<Device> findById(Integer id)
	{
		return deviceService.findById(id);
	}
	
	//Add Device
	@PostMapping(value="devices/addNew")
	public String addNew(Device device) {
		deviceService.save(device);
		return "redirect:/devices";
	}	
	
	@RequestMapping(value="devices/update", method = {RequestMethod.PUT, RequestMethod.GET})
	public String update(Device device) {
		deviceService.save(device);
		return "redirect:/devices";
	}
	
	@RequestMapping(value="devices/delete", method = {RequestMethod.DELETE, RequestMethod.GET})	
	public String delete(Integer id) {
		deviceService.delete(id);
		return "redirect:/devices";
	}
	
	@RequestMapping(value="device/")
	public String findByDeviceIdDescription(Model model) {
		model.addAttribute("devices", deviceService.findByDeviceIdDescription(null));
		//deviceService.findByDeviceIdDescription(deviceIdDescription);
		//return "device";
		//model.addAttribute("devices", deviceService.findAll());
//		model.addAttribute("vehicletypes", deviceTypeService.findAll());
//		model.addAttribute("vehiclemodels", vehicleModelService.findAll());
//		model.addAttribute("vehiclemakes", vehicleMakeService.findAll());
//		model.addAttribute("employees", employeeService.findAll());
//		model.addAttribute("vehiclestatuses", vehicleStatusService.findAll());

		return "device";
	}
	
	
	//Variante 1: returns JSON object
//	@RequestMapping(value="devices/findByKeyword") 
//	@ResponseBody
//	public List<Device> findByKeyword(@RequestParam String keyword)
//	{
//		System.out.println("Keyword test! " + keyword);
//		return deviceService.findByKeyword(keyword);
//	}
	
	//Variante 2: returns device page under URL /findByKeyword/?keyword=... without CSS
	//@GetMapping
	@RequestMapping("/device")  //("devices/findByKeyword/") 
	public String findByKeyword(Model model, @RequestParam(name="keyword") String keyword)
	{
		model.addAttribute("devices", deviceService.findByKeyword(keyword));
		System.out.println("Keyword test! " + keyword);
		return  "device";
	}
	
}
