/**
 * 
 */

$('document').ready(function() {	
	$('.table #editButton').on('click',function(event){		
		event.preventDefault();		
		var href= $(this).attr('href');		
		
		$.get(href, function(device, status){
			
			//var acDate = device.acquisitionDate.substr(0,10);
			//$('#txtIdEdit').val(device.id);
			$('#txtIdEdit').val(device.id);

		});			
		$('#editModal').modal();		
	});
	
	$('.table #detailsButton').on('click',function(event) {
		event.preventDefault();		
		var href= $(this).attr('href');		
		$.get(href, function(device, status){
			$('#idDetails').val(device.id);
			//$('#descriptionDetails').val(deviceType.description);
			//$('#detailsDetails').val(deviceType.details);
			//$('#availabilityDetails').val(deviceStatus.description);
			//$('#lastModifiedByDetails').val(deviceType.lastModifiedBy);
			//$('#lastModifiedDateDetails').val(deviceType.lastModifiedDate.substr(0,19).replace("T", " "));
		});			
		$('#detailsModal').modal();		
	});	
	
	$('.table #deleteButton').on('click',function(event) {
		event.preventDefault();
		var href = $(this).attr('href');
		$('#deleteModal #confirmDeleteButton').attr('href', href);
		$('#deleteModal').modal();		
	});	
	
	//$('.table #photoButton').on('click',function(event) {
		//event.preventDefault();
		//var href = $(this).attr('href');
		//$('#photoModal #devicePhoto').attr('src', href);
		//$('#photoModal').modal();		
	//});	
});