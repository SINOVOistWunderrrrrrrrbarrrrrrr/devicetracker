package com.fleetapp.fleetapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevicetrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
